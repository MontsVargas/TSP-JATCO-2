import {modelo} from "../models/empleados.model.js"

modelo.create ({

    nombre:"Pablo",
    edad:20,
    telefono:449,
    area:"empaques",

})

export const test = () =>{
    console.log("funciona el controlador")
}