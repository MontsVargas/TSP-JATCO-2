import{ Schema, model} from 'mongoose'
const esquema = new Schema ({
    name:{
        type:String
    },
    edad:{
        type:Number
    },
    telefono:{
        type:Number
    },
    area:{
        type:String
        
    }
})
export const modelo = new model ("Tabla de empleados",esquema)